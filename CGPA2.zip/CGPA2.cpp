#include <iostream>
#include <vector>

using namespace std;

int main() {
    int numCourses;
    cout << "Enter the number of courses: ";
    cin >> numCourses;

    vector<int> courseCredits(numCourses);
    vector<double> courseGrades(numCourses);

    for (int i = 0; i < numCourses; ++i) {
        cout << "Enter the credits for course " << i + 1 << ": ";
        cin >> courseCredits[i];
        cout << "Enter the grade (0.0 - 4.0) for course " << i + 1 << ": ";
        cin >> courseGrades[i];
    }

    double totalCredits = 0.0;
    double weightedTotal = 0.0;

    for (int i = 0; i < numCourses; ++i) {
        totalCredits += courseCredits[i];
        weightedTotal += courseCredits[i] * courseGrades[i];
    }

    double cgpa = weightedTotal / totalCredits;

    cout << "CGPA: " << cgpa << endl;

    return 0;
}

